// to jest kod
class Main {
	//zmiana1
  public static void main(String[] args) {
	//zmiana2
    //komentarz    
    int first = 10;
    int second = 20;
    //drugi komentarz
    // add two numbers
    int sum = first + second;
	//zmiana 3
    System.out.println(first + " + " + second + " = "  + sum);
  }
}
